# jenkins-lambda
Demo lambda function build via Jenkins CI
